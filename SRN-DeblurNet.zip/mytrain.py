from time import time

import numpy as np

if __name__ == '__main__':
    # val_loss_log_list = [{'mse': 1, 'psnr': 3}, {'mse': 1, 'psnr': 2}, {'mse': 1, 'psnr': 2}, {'mse': 1, 'psnr': 2}]
    # print(val_loss_log_list[1])
    # for k in val_loss_log_list[1]:
    #     print(k)
    #
    # val_loss_log_dict = {k: float(np.mean([dic[k] for dic in val_loss_log_list]))
    #                      for k, _ in val_loss_log_list[0].items()
    #                      }
    # print(val_loss_log_dict)
    # print([dic['psnr'] for dic in val_loss_log_list])
    t = time()
    print("???")
    for i in range(1000000):
        print("1")
    tt = time()
    print(tt-t)



